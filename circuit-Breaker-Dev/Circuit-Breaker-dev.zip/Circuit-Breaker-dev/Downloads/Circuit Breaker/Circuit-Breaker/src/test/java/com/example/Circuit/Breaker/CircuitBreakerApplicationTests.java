package com.example.Circuit.Breaker;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CircuitBreakerApplicationTests {

	@Test
	void contextLoads() {
	}

}
